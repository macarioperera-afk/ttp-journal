# TTP Journal - Trading Journal App

## Setup & Deploy

### 1. Auf GitHub hochladen
- Gehe zu github.com → "New repository" → Name: "ttp-journal"
- Lade alle Dateien hoch (drag & drop)

### 2. Auf Vercel deployen  
- Gehe zu vercel.com → "Add New Project"
- Verbinde dein GitHub Repository
- Framework: Vite
- Klick "Deploy" → fertig!

### 3. Auf Handy installieren (PWA)
- iPhone: Safari → Teilen → "Zum Home-Bildschirm"
- Android: Chrome → Menü → "Zum Startbildschirm"

## Deine Daten
Alle Trades werden im Browser (localStorage) gespeichert.
Daten bleiben auch nach dem Schließen erhalten.
